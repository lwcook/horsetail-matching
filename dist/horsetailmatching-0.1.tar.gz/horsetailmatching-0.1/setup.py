from distutils.core import setup

setup(name='horsetailmatching',
        version='0.1',
        description='A method for optimization under uncertainty',
        url='https://github.com/lwcook/horsetail-matching',
        author='Laurence W. Cook',
        author_email='lwc24@cam.ac.uk',
        license='MIT',
        packages=['horsetailmatching'],
        zip_safe=False)
