import numpy as np

def talk():
    '''This is the documentation for talk'''

    print 'HELLO WORLD'

def main():

    print 'HELLO WORLD'

if __name__ == "__main__":
    main()
