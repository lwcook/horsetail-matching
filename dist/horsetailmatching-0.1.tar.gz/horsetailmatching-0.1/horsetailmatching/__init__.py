def joke():
    return "Please Laugh"

def main():
    pass

if __name__ == "__main__":
    main()
