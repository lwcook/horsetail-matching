from matcher import talk

def joke():
    '''This is th edocumentation for joke'''
    return "Please Laugh"

def main():
    pass

if __name__ == "__main__":
    main()
