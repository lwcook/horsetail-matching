import numpy as np
import pdb
import math

import utilities as utils

class NIPCSurrogate(object):

    def __init__(self, dimensions=[], order=3, poly_type='legendre'):

        self.dims = dimensions
        self.P = int(order) + 1

        if isinstance(poly_type, basestring):
            self.poly_types = [poly_type for _ in np.arange(self.dims)]
        else:
            self.poly_types = utils.makeIter(poly_type)
        self.J_list = [_define_poly_J(p, self.P) for p in self.poly_types]

        imesh = np.meshgrid(*[np.arange(self.P) for d in np.arange(self.dims)])
        self.index_polys = np.vstack([m.flatten() for m in imesh]).T 
        self.N_poly = len(self.index_polys)
        self.coeffs = np.zeros([self.P for __ in np.arange(self.dims)])

    def predict(self, u):
        y, ysub = 0, np.zeros(self.N_poly)
        for ip in range(self.N_poly):
            inds = tuple(self.index_polys[ip])
            ysub[ip] = self.coeffs[inds]*eval_poly(u, inds, self.J_list)
            y += ysub[ip]

        self.response_components = ysub
        return y

    def train(self, fpoints):
        self.coeffs = 0*self.coeffs

        upoints, wpoints = self.getQuadraturePointsAndWeights()

        for ipoly in np.arange(self.N_poly):

            inds = tuple(self.index_polys[ipoly])
            coeff = 0.0
            for (u, q, w) in zip(upoints, fpoints, wpoints):
                coeff += eval_poly(u, inds, self.J_list)*q*np.prod(w)

            self.coeffs[inds] = coeff
        return None

    def getQuadraturePointsAndWeights(self):

        qw_list, qp_list = [], []
        for ii in np.arange(len(self.J_list)):

            d, Q = np.linalg.eig(self.J_list[ii])
            qp, qpi = d[np.argsort(d)].reshape([d.size, 1]), np.argsort(d)
            qw = (Q[0, qpi]**2).reshape([d.size, 1])

            qw_list.append(qw)
            qp_list.append(qp)

        umesh = np.meshgrid(*qp_list)
        upoints = np.vstack([m.flatten() for m in umesh]).T

        wmesh = np.meshgrid(*qw_list)
        wpoints = np.vstack([m.flatten() for m in wmesh]).T

        return upoints, wpoints

    def getQuadraturePoints(self):
        upoints, _ = self.getQuadraturePointsAndWeights()
        return upoints

## --------------------------------------------------------------------------
## Private funtions for polynomials
## --------------------------------------------------------------------------

def eval_poly(zetavec, nvec, J):
    # Evaluate multi-D polynomials through multiplication
    J = utils.makeIter(J)

    yp = 1
    for ii in range(0, zetavec.size):
        yp *= _eval_poly_1D(zetavec[ii], nvec[ii], J[ii])

    return yp

def _eval_poly_1D(s, k, Jmat):
    k = int(k)
    # Evaluate polynomial order k at a point s using J.
    if k == -1:
        return 0.0
    elif k == 0:
        return 1.0
    else:
        ki = k-1
        if k >= np.shape(Jmat)[0]:
            f = float('nan')
        else:
            beta_k = float(Jmat[ki+1,ki])
            alpha_km1 = float(Jmat[ki,ki])
            if k == 1:
                beta_km1 = 0
            else:
                beta_km1 = float(Jmat[ki,ki-1])
            f = (1.0/float(beta_k))*(
                    (s - alpha_km1)*_eval_poly_1D(s,k-1,Jmat) -
                    beta_km1*_eval_poly_1D(s,k-2,Jmat))

        return f


def _define_poly_J(typestr, order, a=1, b=1):

    n = order
    # Define ab, the matrix of alpha and beta values
    if typestr == 'legendre' or typestr == 'uniform': # The default
        l,r = -1,1
        o = l + (r-l)/2.0
        ab = np.zeros([n, 2],float)

        if n > 0:
            ab[0, 0], ab[0, 1] = o,1

        for k in np.arange(2, n+1,1):
            ik, ab[ik, 0] = k-1, o
            if k == 2:
                numer = float(((r-l)**2)*(k-1)*(k-1)*(k-1)) 
                denom = float(((2*(k-1))**2)*(2*(k-1)+1))
            else:
                numer = float(((r-l)**2)*(k-1)*(k-1)*(k-1)*(k-1)) 
                denom = float(((2*(k-1))**2)*(2*(k-1)+1)*(2*(k-1)-1))
            ab[ik, 1] = numer / denom

    elif typestr == 'hermite' or typestr == 'gaussian':
        # normal with respect to the weighting funciton exp(-x^2) 
        # therefore input distribution has std = 1/sqrt(2)
        # therefore scale input by sqrt(2) to get std(1)
        mu = 0
        mu0 = math.gamma(mu+0.5)
        if n==1:
            ab = np.array([[0, mu0]])
        else:
            ab = np.zeros([n, 2])
            nvechalf = np.array(range(1, n))*0.5
            nvechalf[0::2] += mu
            ab[0, 1], ab[1::,1] = mu0, nvechalf

    # Define J, the jacobi matrix from recurrence coefficients in ab
    J = np.zeros([n,n], float)
    if n == 1:
         J = np.array([[ab[0, 0]]])
    else:
        J[0, 0] = ab[0, 0]
        J[0, 1] = math.sqrt(ab[1, 1])
        for i in np.arange(2, n, 1):
            ii = i-1
            J[ii, ii] = ab[ii,0]
            J[ii, ii-1] = math.sqrt(ab[ii, 1])
            J[ii, ii+1] = math.sqrt(ab[ii+1, 1])
        J[n-1, n-1] = ab[n-1, 0]
        J[n-1, n-2] = math.sqrt(ab[n-1, 1])

    return J
